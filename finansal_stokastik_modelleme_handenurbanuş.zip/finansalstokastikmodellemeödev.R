install.packages("reader")
install.packages("PerformanceAnalytics")
install.packages("ismev")
install.packages("psych")
install.packages('quantmod')  # Finansal verileri çekmek için
install.packages('xts')       # Zaman serisi verileri ile calışmak için
install.packages('fExtremes') # Uc deger dağılımlarını analiz etmek için
install.packages('evd')       # Uç deger teorisi üzerine analiz yapmak için
install.packages('extRemes')  # Genelleştirilmiş uç değer ve Pareto dağılımı için
install.packages('EnvStats')  # İstatistiksel analiz ve çevresel veri analizi için
install.packages('imputeTS')  # Zaman serisindeki eksik değerleri doldurmak için
install.packages('timeSeries')# Zaman serisi verilerini yönetmek ve analiz etmek için


library(reader)
library(ggplot2)
library(dplyr)
library(PerformanceAnalytics)
library(tidyverse)
library(psych)
library(quantmod)  # Finansal verileri (hisse senedi gibi) çekmek için
library(xts)       # Zaman serisi verilerini işlemek için
library(imputeTS)  # Eksik verileri tahmin etmek ve doldurmak için
library(timeSeries)# Zaman serisi verilerini yönetmek için
library(fExtremes) # Uç değer dağılımlarını modellemek için
library(evd)       # Uç değer teorisi analizi için
library(extRemes)  # Uç olayları ve aşırı değerleri analiz etmek için
library(EnvStats)  # İstatistiksel ve çevresel veri analizleri için



data<- read.csv("C:/Users/HANDENUR/Downloads/eurusd_hour.csv/eurusd_hour.csv", sep = ",")
summary(data)
describe(data)
# Eksik değer kontrolü
sum(is.na(data))

# Tarih ve zaman sütunlarını birleştir ve datetime oluştur
data$Datetime <- as.POSIXct(paste(data$Date, data$Time), format="%Y-%m-%d %H:%M")

# b. Fiyat grafiği (Örnek: BO sütunu için fiyat grafiği)
library(ggplot2)
ggplot(data, aes(x = Datetime, y = BO)) +
  geom_line(color = "blue") +
  labs(title = "EUR/USD Fiyat Hareketleri", x = "Zaman", y = "acilis fiyati ") +
  theme_minimal()


#c. Fiyat/getirisi için uygun uç değer dağılımları “Eşiği Aşan Değer” veya “Blok
#Maksima” yöntemleri ile belirleyiniz.

ac_log_returns <- diff(log(data$BO)) # açılış fiyatlarının logaritmik farkları
summary(bo_log_returns)

hist(bo_log_returns , main="logaritmik getirileri", xlab ="acilis log getiri", breaks = 50)

# Esigi Asan Deger (Peak Over Threshold, POT) yöntemi 
# Gerekli kütüphaneleri yükle

library(evd)  # Genelleştirilmiş Pareto Dağılımı ve uç değer analizi
library(ismev)

### Eşik Değerini Belirle (Mean Excess Plot yardımıyla eşik belirle)
#mePlot(bo_log_returns)  # Ortalama aşım grafiği ile aşım miktarını belirlemek

library(evd)

# Ortalama aşım grafiği için özel görselleştirme
threshold_value <- quantile(bo_log_returns, 0.95) # %90 eşik
threshold_value


exceedances <- bo_log_returns[bo_log_returns > threshold_value]  # Eşiği aşan değerler
hist(exceedances, main = "Uc Degerlerin Dagılımı", xlab = "Log Getiri", breaks = 30, col = "lightblue")

exceedance_count <- length(exceedances)
cat("Esik degerinin uzerindeki asiri deger sayisi:", exceedance_count, "\n")

# GPD dağılımı için kütüphaneyi yükle
library(evd)  # Genelleştirilmiş Pareto Dağılımı

# Eşik değeri üzerinde kalan aşım değerlerini seçmiştik
exceedances <- bo_log_returns[bo_log_returns > threshold_value]

# GPD parametrelerinin tahmin edilmesi
gpd_model <- fpot(exceedances, threshold=threshold_value,std.err = FALSE)

# Model sonuçlarını görüntüleme
summary(gpd_model)

# GPD dağılımını görselleştirme
plot(gpd_model, which = 1, main = "GPD Dağılımı ", xlab = "Log Getiri")

#blook maksima yöntemi

library(xts)
library(timeSeries)# Zaman serisi verilerini yönetmek için
library(fExtremes)
library(extRemes)
library(EnvStats)
library(imputeTS)
library(evd)       # Uç değer teorisi analizi için

forex_close<- (data$AC)

# Eksik veya geçersiz satırları kaldır
data <- data[!is.na(data$Datetime) & !is.na(data$AC), ]

# timeSeries formatına çevir
#forex_close <- as.timeSeries(forex_close)
forex_close <- timeSeries(data = data$AC, charvec = data$Datetime)

y <- blockMaxima(forex_close, block = "monthly")
y_df <- as.data.frame(y)
print(y_df)

# GEV modelini oluştur
fit1 = fevd(as.numeric(y))
summary(fit1)

# Modeli görselleştir
plot(fit1)

# Kolmogorov-Smirnov testi
gofTest(as.numeric(y), distribution = "gev", test = "ks")

# Geri dönüş seviyelerini hesapla
return.level(fit1, do.ci = TRUE, return.period = c(2, 5, 10))


# GEV parametrelerini kullanarak AD testi
gofTest(as.numeric(y), distribution = "gev", test = "ad")
library(goftest)
fit_gev <- fevd(y_numeric, type = "GEV")
gev_params <- fit_gev$results$par
ad.test(y_numeric, pgev, gev_params["location"], gev_params["scale"], gev_params["shape"])


#2.soru:İki finansal varlık ile portföy oluşturarak, portföy getirisi, portföy ortalaması ve
#varyansı değerlerini bulunuz. 
library(PerformanceAnalytics)
library(zoo)
library(quantmod)
data2<-read.csv("C:/Users/HANDENUR/Downloads/BTC-Hourly.csv/BTC-Hourly.csv")
head(data2)

# Gerekli paket
library(xts)

# 'data2 ve data1' datasetini xts formatına çeviriyoruz
data1_xts <- xts(data$AC, order.by = as.POSIXct(data$Date))

data2_xts <- xts(data2$close, order.by = as.POSIXct(data2$date))


library(PerformanceAnalytics)

# Log getirileri hesaplama
data1_returns <- Return.calculate(data1_xts, method = "log")
data2_returns <- Return.calculate(data2_xts, method = "log")
options(xts_check_TZ = FALSE)
all_returns <- merge(data1_returns, data2_returns)
all_returns <- na.omit(all_returns)
print(all_returns)

#ortalama
#Portfoy agirliklari (eşit ağırlık verilmiştir)
weight_d1 <- 0.5
weight_d2 <- 0.5

#Portfoy getirileri
portfoy_returns <- weight_d1 * na.omit(data1_returns) + weight_d2 * na.omit(data2_returns)
portfoy_returns
#Portfoy ortalamasi
portfoy_mean <- mean(portfoy_returns)
portfoy_mean

#varyans 
# Kovaryans matrisininin hesaplanmasi
cov_matrix <- cov(all_returns)

# Portfoy varyansinin hesaplanmasi
weights<-c(0.5,0.5)
portfolio_variance <- t(weights) %*% cov_matrix %*% weights

# Portfoy varyansinin yazdirilmasi
print(paste("Portfoy Varyansi:", portfolio_variance))

# Portfoy standart sapmasi
portfolio_sd <- sqrt(portfolio_variance)
print(paste("Portfoy Standart Sapmasi:", portfolio_sd))

# Portfoy standart sapmasi
portfolio_sd <- sqrt(portfolio_variance)
print(paste("Portfoy Standart Sapmasi:", portfolio_sd))

#b. Portföyü oluşturan iki finansal varlığın arasındaki ilişkiyi korelasyon katsayısı
#değerine dayanarak inceleyiniz ve yorumlayınız.

# Porfoydeki getiriler arasindaki iliskinin hesaplanmasi
# Korelasyon matrisinin olusturulmasi
correlation_matrix <- cor(all_returns)

# Korelasyon matrisini yazdirilmasi
print(correlation_matrix)

# Isı haritası için gerekli kütüphaneler
install.packages("corrplot")
library(corrplot)

# Korelasyon matrisi için ısı haritası oluşturma
corrplot(correlation_matrix, method = "color", type = "upper", 
         tl.col = "black", tl.cex = 0.8, number.cex = 0.7, addCoef.col = "black")


#3.soru:Bir finansal varlığın fiyat serisinin belirlediğiniz bir zaman aralığı üzerinden aşağıdaki 
#Markov zincirine dayanan analizlerini (R veya Pyhton üzerinden veya yazılım kullanmadan) gerçekleştiriniz.

# Logaritmik getirileri hesaplayın
ac_log_returns <- diff(log(data$AC))

# Değişimleri pozitif, negatif ve sabit durumlar olarak sınıflandırma
states <- ifelse(ac_log_returns > 0, "Up", 
                 ifelse(ac_log_returns < 0, "Down", "Stable"))
states <- factor(states, levels = c("Up", "Down", "Stable"))

# 2. Adım: Geçiş Matrisini Oluşturma
# Durum geçişleri için bir vektör oluşturuyoruz
#install.packages("markovchain")
library(markovchain)
transitions <- markovchainFit(data = states)

# Geçiş matrisini inceleyelim
transition_matrix <- transitions$estimate@transitionMatrix
print("Gecis Matrisini Gosterelim:")
print(transition_matrix)

# Geçiş matrisini görselleştirme
#install.packages("pheatmap")
library(pheatmap)

pheatmap(transition_matrix, 
         main = "Gecis Matrisi", 
         display_numbers = TRUE, 
         color = colorRampPalette(c("green", "red"))(100))


# 3. Adım: Markov Zinciri Şeması
# Markov zincirini grafik olarak göstermek için plot fonksiyonunu kullanıyoruz
plot(transitions$estimate, main = "Markov Zinciri Durum Seması")

# Alternatif olarak, DiagrammeR kodlarıyla grafiği oluşturuyoruz
states <- colnames(transition_matrix)

graph_code <- "
digraph markov_chain {
    rankdir=LR;
    node [shape=circle, style=filled, color=lightblue];
"

# Her durum için düğümler ekleniyor
for (state in states) {
  graph_code <- paste0(graph_code, state, ";\n")
}

# Her geçiş olasılığı için bağlantı çiziyoruz
for (i in 1:nrow(transition_matrix)) {
  for (j in 1:ncol(transition_matrix)) {
    if (transition_matrix[i, j] > 0) {  # Sadece olasılığı olan geçişleri ekleyelim
      graph_code <- paste0(
        graph_code,
        states[i], " -> ", states[j], 
        " [label=\"", round(transition_matrix[i, j], 2), "\"];\n"
      )
    }
  }
}

# Diyagramı tamamlıyoruz
graph_code <- paste0(graph_code, "}")
# DiagrammeR kullanarak grafiği çiziyoruz
#install.packages("DiagrammeR")
library(DiagrammeR)
DiagrammeR::grViz(graph_code)


# 4. Adım: k. Dönem Geçiş Matrislerini Elde Etme
# İleriye yönelik n dönem için geçiş matrisleri elde edelim
n_periods <- 5  # Örneğin 5 dönem
library(expm)
k_period_transition <- transition_matrix %^% n_periods
print(paste(n_periods, "donemlik gecis matrisi:"))
print(k_period_transition)

# 5. Adım: Denge Dağılımını Hesaplama
# Geçiş matrisinin denge dağılımını buluyoruz
stationary_distribution <- steadyStates(transitions$estimate)
print("Denge Dagılımı:")
print(stationary_distribution)



#2.yol
# Gerekli kütüphaneleri yükleyin
library(dplyr)
library(lubridate)  # Tarih işlemleri için
library(markovchain)

# Haftalık kapanış fiyatlarını hesaplayın
weekly_data <- data %>%
  group_by(week = floor_date(Date, "week")) %>%
  summarize(weekly_close = last(AC))  # Haftanın son fiyatı

# Log getirileri hesaplayın
log_returns <- diff(log(weekly_data$weekly_close))

# Getirileri durumlara ayırın (örneğin, pozitif ve negatif)
# Değişimleri pozitif, negatif ve sabit durumlar olarak sınıflandırma
states <- ifelse(ac_log_returns > 0, "Up", 
                 ifelse(ac_log_returns < 0, "Down", "Stable"))
states <- factor(states, levels = c("Up", "Down", "Stable"))


# Markov zinciri oluşturun
mc_fit <- markovchainFit(data = states)

# Geçiş matrisini görüntüleyin
transition_matrix <- mc_fit$estimate@transitionMatrix
print("Gecis Matrisi:")
print(transition_matrix)

# Denge durumlarını hesaplayın
steady_states <- steadyStates(mc_fit$estimate)
print("Denge Durumları:")
print(steady_states)

#a. Bu finansal varlığın fiyat hareketlerindeki değişimleri (Artış, Sabit, Azalış) baz alarak oluşturacağınız 
#Markov zincirinin 3x3 boyutlu bir-adım geçiş matrisini (P) elde ediniz.
#Bu geçiş matrisinden yararlanarak Üçüncü döneme ait geçiş matrisi olan (P3)’ü bulunuz.

#3.donem icin gecis matrisi
transition_matrix_3 <- transition_matrix %^% 3
round(transition_matrix_3,3)
